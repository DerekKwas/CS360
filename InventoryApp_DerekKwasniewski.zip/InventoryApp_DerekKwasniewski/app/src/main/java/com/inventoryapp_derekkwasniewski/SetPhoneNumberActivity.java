package com.inventoryapp_derekkwasniewski;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class SetPhoneNumberActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsnotification);

        InventoryDatabase db = new InventoryDatabase(getApplicationContext());

        String user = getIntent().getStringExtra("user");

        Button buttonSetPhoneNumber = findViewById(R.id.buttonPhoneNumber);
        EditText editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);

        String currentNumber = db.getPhoneNumber(user);
        editTextPhoneNumber.setText(currentNumber);

        buttonSetPhoneNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If the editText for the phone # is empty or has spaces, do nothing
                if (editTextPhoneNumber.getText().toString().isEmpty() || editTextPhoneNumber.getText().toString().contains(" ")) {
                    return;
                }
                String phoneNumber = editTextPhoneNumber.getText().toString();
                // Set number in databse
                db.setPhoneNumber(user, phoneNumber);
                // After number is set, create intent to go back to InventoryActivity
                Intent intent = new Intent(SetPhoneNumberActivity.this, InventoryActivity.class);
                intent.putExtra("user", user);
                SetPhoneNumberActivity.this.startActivity(intent);
            }
        });
    }
}
