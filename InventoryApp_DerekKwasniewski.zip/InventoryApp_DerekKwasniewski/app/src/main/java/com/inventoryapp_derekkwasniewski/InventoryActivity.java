package com.inventoryapp_derekkwasniewski;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity implements RecyclerViewAdapter.AdapterCallback {

    final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;
    private RecyclerView recyclerView;
    ArrayList<String> name, quantity;
    InventoryDatabase db;
    RecyclerViewAdapter adapter;
    String user;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Set variables
        db = new InventoryDatabase(this);
        // Hold names of items in database
        name = new ArrayList<>();
        // Hold quantities of items in database
        quantity = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView);
        user = getIntent().getStringExtra("user");
        adapter = new RecyclerViewAdapter(this, name, quantity, user);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Button add = findViewById(R.id.buttonAddItem);
        Button settings = findViewById(R.id.buttonSettings);
        displaydata();

        // Check if permission granted for sending SMS, if not, ask for permission
        if (!checkPermission(android.Manifest.permission.SEND_SMS)) {
            ActivityCompat.requestPermissions(this, new String[] {android.Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_REQUEST_CODE);
        }

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
                intent.putExtra("user", user);
                startActivity(intent);
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, SetPhoneNumberActivity.class);
                intent.putExtra("user", user);
                InventoryActivity.this.startActivity(intent);
            }
        });
    }

    // Override callback function from RecyclerViewAdapter to send SMS
    @Override
    public void sendSMSCallback(String itemName) {
        if (checkPermission(android.Manifest.permission.SEND_SMS)) {
            onSend(null, itemName);
        }
    }

    public void onSend(View v, String itemName) {
        String phoneNumber = db.getPhoneNumber(user);
        String smsMessage = itemName + " is low on stock.";

        if (phoneNumber == null || phoneNumber.isEmpty()){
            return;
        }

        // Send text message if user granted permission
        if (checkPermission(android.Manifest.permission.SEND_SMS)) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, smsMessage, null, null);
        }
    }

    // Check if user has granted permission
    public Boolean checkPermission(String permission) {
        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }

    private void displaydata() {
        Cursor cursor = db.getData();
        if (cursor.getCount() == 0) {
            Toast.makeText(InventoryActivity.this, "No Entries Exist", Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            while (cursor.moveToNext()) {
                name.add(cursor.getString(1));
                quantity.add(cursor.getString(2));
            }
        }
    }
}
