package com.inventoryapp_derekkwasniewski;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {

    private ArrayList nameArray, quantityArray;
    private Context context;
    InventoryDatabase db;
    String user;
    private AdapterCallback adapterCallback;



    public RecyclerViewAdapter(Context context, ArrayList nameArray, ArrayList quantityArray, String user) {
        // Set variables when adapter is created
        this.context = context;
        this.nameArray = nameArray;
        this.quantityArray = quantityArray;
        this.db = new InventoryDatabase(context);
        this.user = user;

        // Set adapter callback so when a text needs to be sent, tell InventoryActivity to send one
        try {
            adapterCallback = ((AdapterCallback) context);
        } catch (ClassCastException e) {
            throw new ClassCastException("Activity must implement AdapterCallBack");
        }
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate Layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, @SuppressLint("RecyclerView") int position) {
        // Set the data to textview and quantity.
        holder.textViewName.setText(String.valueOf(nameArray.get(position)));
        holder.textViewQuantity.setText(String.valueOf(quantityArray.get(position)));
        holder.position = position;
    }

    public static interface AdapterCallback {
        void sendSMSCallback(String itemName);
    }

    @Override
    public int getItemCount() {
        // this method returns the size of recyclerview
        return nameArray.size();
    }

    // View Holder Class to handle Recycler View.
    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName, textViewQuantity;
        int position;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewQuantity = itemView.findViewById(R.id.textViewQuantity);

            itemView.findViewById(R.id.buttonAdd).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Increment item
                    String newQuantity = db.incrementItem(nameArray.get(getAdapterPosition()).toString());
                    textViewQuantity.setText(newQuantity);
                }
            });

            itemView.findViewById(R.id.buttonSubtract).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // If item is already low/zero, don't do anything.  This prevents repetitive texts
                    if (db.isItemLow(nameArray.get(getAdapterPosition()).toString())) {
                        return;
                    }
                    // Decrement item and if item becomes low, send a text
                    String newQuantity = db.decrementItem(nameArray.get(getAdapterPosition()).toString());
                    if (db.isItemLow(nameArray.get(getAdapterPosition()).toString())) {
                        adapterCallback.sendSMSCallback(nameArray.get(getAdapterPosition()).toString());
                    }
                    textViewQuantity.setText(newQuantity);
                }
            });

            itemView.findViewById(R.id.buttonDelete).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Delete the item
                    db.deleteItem(nameArray.get(getAdapterPosition()).toString());
                    // Remove item from arrays so the recycler view doesn't populate with these values
                    nameArray.remove(getAdapterPosition());
                    nameArray.trimToSize();
                    quantityArray.remove(getAdapterPosition());
                    quantityArray.trimToSize();

                    // Notify recycler view an item has been removed and update
                    notifyItemRemoved(getAdapterPosition());
                }
            });
        }
    }
}