package com.inventoryapp_derekkwasniewski;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class InventoryDatabase extends SQLiteOpenHelper {
    // Initialize variables
    private static final String DATABASE_NAME = "inventory.db";
    Context context;

    InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, 1);
        this.context = context;
    }

    private static final class LoginTable {
        private static final String TABLE = "login";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_NUMBER = "number";
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create tables
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USERNAME + " text, " +
                LoginTable.COL_PASSWORD + " text," +
                LoginTable.COL_NUMBER + " text)");

        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_NAME + " text, " +
                InventoryTable.COL_QUANTITY + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }


    // LOGIN TABLE METHODS
    public long addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USERNAME, username);
        values.put(LoginTable.COL_PASSWORD, password);

        // Insert and return the ID of the new user
        return db.insert(LoginTable.TABLE, null, values);
    }

    public Boolean checkLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where username = ? and password = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username, password});

        // Moves cursor to first row of query, returns false if the cursor is empty
        return cursor.moveToFirst();
    }

    public Boolean checkUsername(String username) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username});

        // Moves cursor to first row of query, returns false if the cursor is empty
        return cursor.moveToFirst();
    }

    public void setPhoneNumber(String user, String number) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_NUMBER, number);

        String whereClause = LoginTable.COL_USERNAME + " = ?";
        String [] whereArgs = new String[] {user};

        db.update(LoginTable.TABLE, values, whereClause, whereArgs);
    }

    public String getPhoneNumber(String user) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {user});

        // Moves cursor to first row of query, returns false if the cursor is empty
        cursor.moveToFirst();
        return cursor.getString(3);
    }

    // INVENTORY TABLE METHODS
    public long addItem(String name, String quantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, name);
        values.put(InventoryTable.COL_QUANTITY, quantity);

        // Insert and return the ID of the new item
        return db.insert(InventoryTable.TABLE, null, values);
    }

    public Boolean checkItem(String name) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryTable.TABLE + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {name});

        // Moves cursor to first row of query, returns false if the cursor is empty
        return cursor.moveToFirst();
    }

    public String incrementItem(String name) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryTable.TABLE + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {name});
        cursor.moveToFirst();
        String quantity = cursor.getString(2);
        Integer newIntQuantity = (Integer.parseInt(quantity)) + 1;
        String newQuantity = newIntQuantity.toString();

        db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_QUANTITY, newQuantity);

        String whereClause = InventoryTable.COL_NAME + " = ?";
        String [] whereArgs = new String[] {name};

        db.update(InventoryTable.TABLE, values, whereClause, whereArgs);

        return newQuantity;
    }

    public String decrementItem(String name) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryTable.TABLE + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {name});
        cursor.moveToFirst();
        String quantity = cursor.getString(2);
        Integer intQuantity = (Integer.parseInt(quantity));
        if (intQuantity <= 0) {
            intQuantity = 0;
        }
        else {
            intQuantity -= 1;
        }
        String newQuantity = intQuantity.toString();

        db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_QUANTITY, newQuantity);

        String whereClause = InventoryTable.COL_NAME + " = ?";
        String [] whereArgs = new String[] {name};

        db.update(InventoryTable.TABLE, values, whereClause, whereArgs);

        return newQuantity;
    }

    public Boolean isItemLow(String name) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryTable.TABLE + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {name});
        cursor.moveToFirst();
        String quantity = cursor.getString(2);
        Integer intQuantity = (Integer.parseInt(quantity));

        return intQuantity <= 0;
    }

    public void deleteItem (String name) {
        SQLiteDatabase db = getWritableDatabase();

        String whereClause = InventoryTable.COL_NAME + " = ?";
        String [] whereArgs = new String[] {name};

        db.delete(InventoryTable.TABLE, whereClause, whereArgs);
    }

    public String getName(Integer index) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        cursor.moveToFirst();
        cursor.move(index);

        return cursor.getString(0);
    }

    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from " + InventoryTable.TABLE, null);
    }
}
