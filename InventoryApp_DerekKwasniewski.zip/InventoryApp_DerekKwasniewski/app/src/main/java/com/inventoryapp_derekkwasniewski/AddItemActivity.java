package com.inventoryapp_derekkwasniewski;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class AddItemActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        InventoryDatabase db = new InventoryDatabase(getApplicationContext());

        Button addItem = findViewById(R.id.buttonSettings);
        EditText textViewName = findViewById(R.id.editTextItemName);
        EditText textViewQuantity = findViewById(R.id.editTextItemQuantity);

        String user = getIntent().getStringExtra("user");;

        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemName = textViewName.getText().toString();
                if (textViewName.getText().toString().isEmpty()) {
                    Toast.makeText(AddItemActivity.this, R.string.new_itemname_empty, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (textViewQuantity.getText().toString().isEmpty()) {
                    Toast.makeText(AddItemActivity.this, R.string.new_itemquantity_empty, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (textViewName.getText().toString().contains(" ") || textViewQuantity.getText().toString().contains(" ")) {
                    Toast.makeText(AddItemActivity.this, R.string.new_item_has_spaces, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!db.checkItem(itemName)) {
                    db.addItem(itemName, textViewQuantity.getText().toString());
                    Intent intent = new Intent(AddItemActivity.this, InventoryActivity.class);
                    intent.putExtra("user", user);
                    AddItemActivity.this.startActivity(intent);
                }
                else {
                    Toast.makeText(AddItemActivity.this, "Item already exists.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
