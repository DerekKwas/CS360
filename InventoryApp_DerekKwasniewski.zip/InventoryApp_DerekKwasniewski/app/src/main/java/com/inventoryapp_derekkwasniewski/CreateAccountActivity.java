package com.inventoryapp_derekkwasniewski;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createaccount);

        InventoryDatabase inventoryDatabase = new InventoryDatabase(getApplicationContext());

        // Set Layout Variables
        Button create = findViewById(R.id.buttonSettings);
        EditText editNewUsername = findViewById(R.id.editTextItemName);
        EditText editNewPassword = findViewById(R.id.editTextItemQuantity);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editNewUsername.getText().toString().isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, R.string.new_username_empty, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (editNewPassword.getText().toString().isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, R.string.new_password_empty, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (editNewUsername.getText().toString().contains(" ") || editNewPassword.getText().toString().contains(" ")) {
                    Toast.makeText(CreateAccountActivity.this, R.string.new_account_has_spaces, Toast.LENGTH_SHORT).show();
                    return;
                }

                if (inventoryDatabase.checkUsername(editNewUsername.getText().toString())) {
                    Toast.makeText(CreateAccountActivity.this, R.string.username_exists, Toast.LENGTH_SHORT).show();
                    editNewUsername.setText("");
                    editNewPassword.setText("");
                }
                else {
                    inventoryDatabase.addUser(editNewUsername.getText().toString(), editNewPassword.getText().toString());
                    Intent intent = new Intent(CreateAccountActivity.this, MainActivity.class);
                    CreateAccountActivity.this.startActivity(intent);
                }
            }
        });
    }
}
