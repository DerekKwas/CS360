package com.inventoryapp_derekkwasniewski;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        InventoryDatabase inventoryDatabase = new InventoryDatabase(getApplicationContext());

        // This is test code that can be uncommented to have default values in the login table and inventory table
//        if (!inventoryDatabase.checkUsername("Admin")) {
//            inventoryDatabase.addUser("Admin", "1234");
//        }
//        if (!inventoryDatabase.checkItem("Bread")) {
//            inventoryDatabase.addItem("Bread", "10");
//        }
//        if (!inventoryDatabase.checkItem("Mac and Cheese")) {
//            inventoryDatabase.addItem("Mac and Cheese", "15");
//        }
//        if (!inventoryDatabase.checkItem("Potatoes")) {
//            inventoryDatabase.addItem("Potatoes", "25");
//        }

        // Set Layout Variables
        Button login = findViewById(R.id.buttonLogin);
        Button create = findViewById(R.id.buttonCreate);
        EditText editUsername = findViewById(R.id.editTextUsername);
        EditText editPassword = findViewById(R.id.editTextPassword);

        // Set Login Button Listener
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();

                if (!username.isEmpty() && !password.isEmpty()) {
                    Boolean isUser = inventoryDatabase.checkLogin(username, password);
                    if (isUser) {
                        Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                        // OPTIONAL PARAMETERS = intent.putExtra("key", value);
                        intent.putExtra("user", username);
                        MainActivity.this.startActivity(intent);
                    }
                    else {
                        Toast.makeText(MainActivity.this, R.string.login_failed, Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Log.d("Login", "Login failed! User not present");
                }
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });
    }

    public Boolean checkPermission(String permission) {
        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
}